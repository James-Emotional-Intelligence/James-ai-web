import { z } from 'zod';

export const LoginRequestSchema = z.object({
  email: z.string().trim().email({ message: 'Vui lòng nhập địa chỉ email hợp lệ' }),
  password: z.string().min(6, { message: 'Mật khẩu phải có ít nhất 6 ký tự' }),
  rememberMe: z.boolean().default(false),
});

export const RegisterRequestSchema = z
  .object({
    displayName: z.string().trim().min(2, { message: 'Họ và tên tối thiểu 2 ký tự' }),
    preferredName: z.string().trim().optional().or(z.literal('')),
    email: z.string().trim().email({ message: 'Vui lòng nhập địa chỉ email hợp lệ' }),
    gradeLevel: z.coerce.number().min(6, { message: 'Khối lớp từ 6 đến 12' }).max(12, { message: 'Khối lớp từ 6 đến 12' }).default(9),
    password: z.string().min(6, { message: 'Mật khẩu phải có ít nhất 6 ký tự' }),
    confirmPassword: z.string().min(6, { message: 'Mật khẩu xác nhận phải có ít nhất 6 ký tự' }),
    registrationCode: z
      .string()
      .trim()
      .max(64, { message: 'Mã ưu đãi không quá 64 ký tự' })
      .regex(/^[A-Za-z0-9-_]+$/, { message: 'Mã ưu đãi chỉ gồm chữ cái, số và dấu gạch' })
      .optional()
      .or(z.literal('')),
    termsAccepted: z.boolean().refine((val) => val === true, {
      message: 'Vui lòng đồng ý với điều khoản sử dụng và chính sách bảo mật',
    }),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: 'Mật khẩu xác nhận không khớp',
    path: ['confirmPassword'],
  });

export const AuthUserSchema = z.object({
  id: z.string(),
  email: z.string(),
  displayName: z.string(),
  preferredName: z.string(),
  locale: z.string().default('vi-VN'),
  timezone: z.string().default('Asia/Ho_Chi_Minh'),
  ageBand: z.string().default('grade_9'),
  status: z.enum(['active', 'inactive']).default('active'),
  createdAt: z.string(),
});

export const SafeAuthResponseSchema = z.object({
  user: AuthUserSchema,
  profile: z.any(),
  isDemo: z.boolean().default(false),
  message: z.string().optional(),
});

export const VoiceGoalExtractionSchema = z.object({
  transcript: z.string(),
  intent: z.string(),
  subject: z.string(),
  topics: z.array(z.string()),
  deadline: z.string().optional(),
  examDate: z.string().optional(),
  estimatedMinutes: z.number().default(45),
  preferredWindows: z.array(z.string()).default([]),
  constraints: z.array(z.string()).default([]),
  missingFields: z.array(z.string()).default([]),
  confidence: z.number().min(0).max(1).default(0.9),
  clarification: z.string().optional(),
});

export const TaskDecompositionSchema = z.object({
  goalSummary: z.string(),
  tasks: z.array(
    z.object({
      title: z.string(),
      objective: z.string(),
      subjectRef: z.string(),
      topicRefs: z.array(z.string()),
      estimatedMinutes: z.number().min(15).max(180),
      minSessionMinutes: z.number().default(20),
      maxSessionMinutes: z.number().default(60),
      splittable: z.boolean().default(false),
      priority: z.enum(['low', 'medium', 'high']),
      difficulty: z.enum(['easy', 'medium', 'hard']),
      dueAt: z.string().optional(),
      prerequisites: z.array(z.string()).default([]),
      dependencies: z.array(z.string()).default([]),
      successCriteria: z.array(z.string()),
      excellentCriteria: z.array(z.string()),
      materials: z.array(z.string()).default([]),
      rationale: z.string(),
    })
  ),
});

export const StepSchema = z.object({
  order: z.number(),
  title: z.string(),
  plannedMinutes: z.number(),
  instruction: z.string(),
  expectedOutput: z.string(),
  tips: z.array(z.string()),
});

export const ExecutionGuideSchema = z.object({
  objective: z.string(),
  whyItMatters: z.string(),
  prerequisites: z.array(z.string()),
  materials: z.array(z.string()),
  preparationChecklist: z.array(z.string()),
  steps: z.array(StepSchema),
  successCriteria: z.array(z.string()),
  excellentCriteria: z.array(z.string()),
  evidenceRequired: z.array(z.string()),
  commonMistakes: z.array(z.string()),
  fallbackAction: z.string(),
  completionQuestions: z.array(z.string()),
  nextAction: z.string(),
});

export const QuizQuestionDraftSchema = z.object({
  type: z.enum(['multiple_choice', 'true_false', 'short_answer']),
  prompt: z.string(),
  options: z.array(z.object({ id: z.string(), text: z.string() })).optional(),
  correctAnswer: z.string(),
  rubric: z.string().optional(),
  explanation: z.string(),
  difficulty: z.enum(['easy', 'medium', 'hard']),
  topicRef: z.string(),
  sourceReference: z.string().optional(),
});

export const QuizDraftSchema = z.object({
  title: z.string(),
  sourceScope: z.string(),
  learningObjectives: z.array(z.string()),
  questions: z.array(QuizQuestionDraftSchema),
});

// ==========================================
// Canonical 16 Jami AI Tools Schemas
// ==========================================

export const PreviewCreateTaskArgsSchema = z.object({
  title: z.string().trim().min(1, 'Tiêu đề nhiệm vụ không được để trống'),
  subjectName: z.string().optional(),
  estimatedMinutes: z.coerce.number().int().min(5).max(480).default(45),
  priority: z.enum(['low', 'medium', 'high']).default('medium'),
  difficulty: z.enum(['easy', 'medium', 'hard']).default('medium'),
  dueAt: z.string().datetime({ offset: true }).optional(),
  notes: z.string().optional(),
});

export const PreviewCreateScheduledTaskArgsSchema = z.object({
  title: z.string().trim().min(1, 'Tiêu đề ca học không được để trống'),
  subjectName: z.string().optional(),
  scheduledStartAt: z.string().datetime({ offset: true }),
  scheduledEndAt: z.string().datetime({ offset: true }).optional(),
  estimatedMinutes: z.coerce.number().int().min(5).max(480).default(45),
  priority: z.enum(['low', 'medium', 'high']).default('medium'),
  notes: z.string().optional(),
}).refine((data) => !data.scheduledEndAt || new Date(data.scheduledEndAt).getTime() > new Date(data.scheduledStartAt).getTime(), {
  message: 'Thời gian kết thúc phải sau thời gian bắt đầu',
  path: ['scheduledEndAt'],
});

export const PreviewAddBusyEventArgsSchema = z.object({
  title: z.string().trim().min(1, 'Tiêu đề sự kiện bận không được để trống'),
  startsAt: z.string().datetime({ offset: true }),
  endsAt: z.string().datetime({ offset: true }),
  type: z.enum(['extra_class', 'meal', 'sleep', 'commute', 'personal']).default('personal'),
  isAllDay: z.boolean().default(false),
  notes: z.string().optional(),
  commuteBeforeMinutes: z.coerce.number().int().min(0).max(180).default(0),
  commuteAfterMinutes: z.coerce.number().int().min(0).max(180).default(0),
}).refine((data) => new Date(data.endsAt).getTime() > new Date(data.startsAt).getTime(), {
  message: 'Thời gian kết thúc phải sau thời gian bắt đầu',
  path: ['endsAt'],
});

export const PreviewReplanTasksArgsSchema = z.object({
  reason: z.string().trim().min(1),
  strategy: z.enum(['balanced', 'urgent_first', 'deep_work']).default('balanced'),
  daysCount: z.coerce.number().int().min(1).max(30).default(7),
  targetDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  preserveLocked: z.boolean().default(true),
});

export const PreviewAddTimetableEntryArgsSchema = z.object({
  timetableId: z.string().optional(),
  title: z.string().trim().min(1, 'Tiêu đề tiết học không được để trống'),
  subjectName: z.string().optional(),
  teacher: z.string().optional(),
  dayOfWeek: z.coerce.number().int().min(1).max(7),
  startLocalTime: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/),
  endLocalTime: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/),
  location: z.string().optional(),
  room: z.string().optional(),
  commuteBeforeMinutes: z.coerce.number().int().min(0).max(180).default(0),
  commuteAfterMinutes: z.coerce.number().int().min(0).max(180).default(0),
}).refine((data) => data.endLocalTime > data.startLocalTime, {
  message: 'Giờ kết thúc phải sau giờ bắt đầu',
  path: ['endLocalTime'],
});

export const PreviewCreateExamArgsSchema = z.object({
  title: z.string().trim().min(1, 'Tiêu đề kỳ kiểm tra không được để trống'),
  subjectName: z.string().trim().min(1, 'Tên môn học không được để trống'),
  examAt: z.string().datetime({ offset: true }),
  importance: z.enum(['low', 'medium', 'high', 'critical']).default('high'),
  targetScore: z.coerce.number().min(0).max(10).optional(),
  scopeText: z.string().optional(),
  topics: z.array(z.object({
    name: z.string().trim().min(1),
    weight: z.coerce.number().min(0).optional(),
  })).default([]),
});
export const PreviewCreateExamPlanArgsSchema = PreviewCreateExamArgsSchema;

export const PreviewCreateMistakeEntryArgsSchema = z.object({
  subjectName: z.string().optional(),
  topic: z.string().optional(),
  questionText: z.string().min(1, 'Nội dung câu hỏi không được để trống'),
  selectedAnswer: z.string().optional(),
  correctAnswer: z.string().min(1, 'Đáp án đúng không được để trống'),
  mistakeReason: z.string().optional(),
  correctSolution: z.string().min(1, 'Lời giải chuẩn xác không được để trống'),
  lessonLearned: z.string().optional(),
  severity: z.enum(['minor', 'medium', 'critical']).default('medium'),
});

export const PreviewCreateReminderArgsSchema = z.object({
  title: z.string().min(1, 'Nội dung nhắc nhở không được để trống'),
  body: z.string().optional(),
  scheduledFor: z.string().datetime({ offset: true }),
  priority: z.enum(['low', 'medium', 'high']).default('medium'),
  actionUrl: z.string().regex(/^\/[A-Za-z0-9/_-]*$/).optional(),
});

export const PreviewMarkTaskCompletedArgsSchema = z.object({
  taskId: z.string().optional(),
  taskTitle: z.string().optional(),
}).refine((data) => Boolean(data.taskId || data.taskTitle), {
  message: 'Cần có taskId hoặc taskTitle',
  path: ['taskId'],
});

export const PreviewCancelEventArgsSchema = z.object({
  eventType: z.enum(['busy_event', 'timetable_entry', 'task', 'reminder']),
  eventId: z.string().min(1, 'Mã sự kiện cần hủy không được để trống'),
  reason: z.string().optional(),
});

export const GetDailyScheduleArgsSchema = z.object({
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
});

export const GetSubjectProgressArgsSchema = z.object({
  subject: z.string().optional(),
  subjectName: z.string().optional(),
});

export const GetUpcomingExamsArgsSchema = z.object({
  daysAhead: z.coerce.number().min(1).max(365).default(30),
});

export const GetMistakeSummaryArgsSchema = z.object({
  subject: z.string().optional(),
  subjectName: z.string().optional(),
});

export const GetUnreadNotificationsArgsSchema = z.object({
  limit: z.coerce.number().min(1).max(50).default(10),
});

export const GetTaskDetailsArgsSchema = z.object({
  taskId: z.string().min(1, 'Mã nhiệm vụ không được để trống'),
});

export const SearchMaterialsArgsSchema = z.object({
  query: z.string().min(1, 'Từ khóa tìm kiếm không được để trống'),
  limit: z.coerce.number().min(1).max(20).default(5),
});

export const NavigateToArgsSchema = z.object({
  route: z.enum([
    '/today',
    '/timetable',
    '/tasks',
    '/focus',
    '/exams',
    '/materials',
    '/reports',
    '/notifications',
    '/settings',
    '/jami',
  ]),
  reason: z.string().optional(),
});

export const GetNextTaskArgsSchema = z.object({});

export const StartFocusTimerArgsSchema = z.object({
  plannedMinutes: z.coerce.number().min(5).max(180).default(25),
  taskId: z.string().optional(),
});

export const JamiActionIntentSchema = z.union([
  z.object({ kind: z.literal('none') }),
  z.object({ kind: z.literal('read'), toolName: z.literal('get_daily_schedule'), arguments: GetDailyScheduleArgsSchema.default({}) }),
  z.object({ kind: z.literal('read'), toolName: z.literal('get_next_task'), arguments: GetNextTaskArgsSchema.default({}) }),
  z.object({ kind: z.literal('read'), toolName: z.literal('get_subject_progress'), arguments: GetSubjectProgressArgsSchema.default({}) }),
  z.object({ kind: z.literal('read'), toolName: z.literal('get_upcoming_exams'), arguments: GetUpcomingExamsArgsSchema.default({ daysAhead: 30 }) }),
  z.object({ kind: z.literal('read'), toolName: z.literal('get_mistake_summary'), arguments: GetMistakeSummaryArgsSchema.default({}) }),
  z.object({ kind: z.literal('read'), toolName: z.literal('get_unread_notifications'), arguments: GetUnreadNotificationsArgsSchema.default({ limit: 10 }) }),
  z.object({ kind: z.literal('read'), toolName: z.literal('get_task_details'), arguments: GetTaskDetailsArgsSchema }),
  z.object({ kind: z.literal('read'), toolName: z.literal('search_materials'), arguments: SearchMaterialsArgsSchema }),
  z.object({ kind: z.literal('read'), toolName: z.literal('navigate_to'), arguments: NavigateToArgsSchema }),
  z.object({ kind: z.literal('immediate'), toolName: z.literal('start_focus_timer'), arguments: StartFocusTimerArgsSchema.default({ plannedMinutes: 25 }) }),
  z.object({ kind: z.literal('mutate'), toolName: z.literal('preview_create_task'), arguments: PreviewCreateTaskArgsSchema }),
  z.object({ kind: z.literal('mutate'), toolName: z.literal('preview_create_scheduled_task'), arguments: PreviewCreateScheduledTaskArgsSchema }),
  z.object({ kind: z.literal('mutate'), toolName: z.literal('preview_add_timetable_entry'), arguments: PreviewAddTimetableEntryArgsSchema }),
  z.object({ kind: z.literal('mutate'), toolName: z.literal('preview_add_busy_event'), arguments: PreviewAddBusyEventArgsSchema }),
  z.object({ kind: z.literal('mutate'), toolName: z.literal('preview_replan_tasks'), arguments: PreviewReplanTasksArgsSchema }),
  z.object({ kind: z.literal('mutate'), toolName: z.literal('preview_create_exam'), arguments: PreviewCreateExamArgsSchema }),
  z.object({ kind: z.literal('mutate'), toolName: z.literal('preview_create_mistake_entry'), arguments: PreviewCreateMistakeEntryArgsSchema }),
  z.object({ kind: z.literal('mutate'), toolName: z.literal('preview_create_reminder'), arguments: PreviewCreateReminderArgsSchema }),
  z.object({ kind: z.literal('mutate'), toolName: z.literal('preview_mark_task_completed'), arguments: PreviewMarkTaskCompletedArgsSchema }),
  z.object({ kind: z.literal('mutate'), toolName: z.literal('preview_cancel_event'), arguments: PreviewCancelEventArgsSchema }),
]);

export const TimetableOcrPreviewSchema = z.object({
  timetableName: z.string().trim().min(1).max(150),
  entries: z.array(z.object({
    dayOfWeek: z.number().int().min(1).max(7),
    periodIndex: z.number().int().min(1).max(20).optional(),
    session: z.enum(['morning', 'afternoon', 'evening']).optional(),
    title: z.string().trim().min(1).max(200),
    startLocalTime: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/).optional(),
    endLocalTime: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/).optional(),
    room: z.string().trim().max(100).optional(),
    teacher: z.string().trim().max(100).optional(),
    confidence: z.number().min(0).max(1),
    sourceCell: z.string().trim().max(100).optional(),
  }).strict()).max(200),
  warnings: z.array(z.string().trim().max(300)).max(50),
  requiresReview: z.boolean(),
}).strict();

export const TimetableOcrImportRequestSchema = z.object({
  imageBase64: z.string().min(16).max(12 * 1024 * 1024),
  mimeType: z.enum(['image/jpeg', 'image/png', 'image/webp']),
}).strict();

export const TimetableOcrConfirmSchema = z.object({
  timetableName: z.string().trim().min(1).max(150),
  replaceExisting: z.boolean().optional().default(false),
  entries: TimetableOcrPreviewSchema.shape.entries.min(1),
}).strict().superRefine((data, ctx) => {
  const seen = new Set<string>();
  for (const [index, entry] of data.entries.entries()) {
    if (!entry.startLocalTime || !entry.endLocalTime || entry.endLocalTime <= entry.startLocalTime) {
      ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['entries', index], message: 'Mỗi tiết phải có giờ bắt đầu/kết thúc hợp lệ.' });
    }
    const key = `${entry.dayOfWeek}:${entry.startLocalTime || ''}:${entry.endLocalTime || ''}`;
    if (seen.has(key)) ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['entries', index], message: 'Các tiết OCR bị chồng lấp.' });
    seen.add(key);
  }
});

export const JamiResponseSchema = z.object({
  message: z.string(),
  emotion: z.enum([
    'idle',
    'listening',
    'thinking',
    'speaking',
    'guiding',
    'focus',
    'reminding',
    'celebrating',
    'encouraging',
    'sleeping',
    'error',
  ]),
  suggestedActions: z.array(z.string()),
  requiresConfirmation: z.boolean().default(false),
  confirmationSummary: z.string().optional(),
  citationsToUserMaterial: z.array(z.string()).default([]),
  actionIntent: JamiActionIntentSchema.optional(),
});

// ==========================================
// Timetable & Scheduler Schemas
// ==========================================

const TimeStringRegex = /^([01]\d|2[0-3]):[0-5]\d$/;

export const TimetableEntryInputSchema = z
  .object({
    timetableId: z.string().optional(),
    subjectId: z.string().nullable().optional(),
    title: z.string().trim().min(1, { message: 'Tiêu đề tiết học không được để trống' }).max(150),
    teacher: z.string().trim().max(100).optional().or(z.literal('')),
    dayOfWeek: z.coerce.number().int().min(1, { message: 'Thứ trong tuần từ 1 (Thứ 2) đến 7 (Chủ Nhật)' }).max(7),
    startLocalTime: z.string().regex(TimeStringRegex, { message: 'Giờ bắt đầu phải có định dạng HH:mm (00:00 - 23:59)' }),
    endLocalTime: z.string().regex(TimeStringRegex, { message: 'Giờ kết thúc phải có định dạng HH:mm (00:00 - 23:59)' }),
    location: z.string().trim().max(100).optional().or(z.literal('')),
    commuteBeforeMinutes: z.coerce.number().int().min(0).max(180).default(15),
    commuteAfterMinutes: z.coerce.number().int().min(0).max(180).default(15),
  })
  .refine((data) => data.startLocalTime < data.endLocalTime, {
    message: 'Giờ kết thúc phải sau giờ bắt đầu',
    path: ['endLocalTime'],
  });

export const SchoolTimetableInputSchema = z.object({
  name: z.string().trim().min(1, { message: 'Tên thời khóa biểu không được để trống' }).max(100),
  validFrom: z.string().optional().nullable(),
  validTo: z.string().optional().nullable(),
  timezone: z.string().default('Asia/Ho_Chi_Minh'),
  isActive: z.boolean().default(true),
  entries: z.array(TimetableEntryInputSchema).optional(),
});

export const TimetableExceptionCreateSchema = z.object({
  occurrenceDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, { message: 'Định dạng ngày phải là YYYY-MM-DD' }),
  exceptionType: z.enum(['cancelled', 'rescheduled', 'skip']).default('cancelled'),
  reason: z.string().max(255).optional().nullable(),
});

export const ClassSessionCheckinSubmitSchema = z
  .object({
    timetableEntryId: z.string().min(1, { message: 'Mã tiết học không được để trống' }),
    timetableEntryIds: z.array(z.string()).optional(),
    occurrenceDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, { message: 'Định dạng ngày phải là YYYY-MM-DD' }),
    learnedContent: z.string().max(3000).optional().nullable(),
    homework: z.string().max(3000).optional().nullable(),
    homeworkImageMaterialId: z.string().optional().nullable(),
    hasNoHomework: z.boolean().optional().default(false),
    homeworkStatus: z.enum(['unanswered', 'has_homework', 'no_homework']).optional(),
    reflection: z.string().max(3000).optional().nullable(),
    understandingLevel: z.enum(['very_easy', 'normal', 'hard', 'not_understood']).optional().nullable(),
    attendanceStatus: z.enum(['attended', 'absent']).default('attended'),
    createTaskForHomework: z.boolean().optional().default(false),
    dueAt: z.string().optional().nullable(),
    estimatedMinutes: z.coerce.number().int().min(5).max(360).optional().nullable(),
    taskId: z.string().optional().nullable(),
  })
  .superRefine((data, ctx) => {
    const hasHomeworkText = Boolean(data.homework && data.homework.trim().length > 0);
    const hasHomeworkImage = Boolean(data.homeworkImageMaterialId && data.homeworkImageMaterialId.trim().length > 0);
    const isNoHomework = data.hasNoHomework === true || data.homeworkStatus === 'no_homework';

    if (isNoHomework && (hasHomeworkText || hasHomeworkImage)) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'Không thể vừa tích "Không có BTVN" vừa đính kèm ảnh hoặc nhập nội dung BTVN.',
        path: ['hasNoHomework'],
      });
    }

    if (data.createTaskForHomework && (isNoHomework || (!hasHomeworkText && !hasHomeworkImage))) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'Chỉ có thể tạo nhiệm vụ khi có nội dung hoặc hình ảnh BTVN.',
        path: ['createTaskForHomework'],
      });
    }

    if (data.attendanceStatus === 'absent' && data.createTaskForHomework) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'Không tạo nhiệm vụ BTVN khi báo nghỉ tiết học.',
        path: ['createTaskForHomework'],
      });
    }
  });

// ==========================================
// Soft Books (Sách Mềm) Schemas
// ==========================================

export const ALLOWED_BOOK_MIME_TYPES = [
  'application/pdf',
  'application/epub+zip',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'text/plain',
  'text/markdown',
] as const;

export const BookUploadIntentSchema = z.object({
  title: z.string().trim().min(1, { message: 'Tiêu đề sách không được để trống' }).max(255),
  subjectId: z.string().min(1, { message: 'Vui lòng chọn môn học cho sách' }),
  fileName: z.string().trim().min(1, { message: 'Tên tệp không hợp lệ' }),
  mimeType: z.string().refine(
    (m) =>
      ALLOWED_BOOK_MIME_TYPES.includes(m as any) ||
      m.startsWith('text/') ||
      m === 'application/zip',
    { message: 'Định dạng tệp không được hỗ trợ. Vui lòng tải PDF, EPUB, DOCX, TXT hoặc Markdown.' }
  ),
  sizeBytes: z.coerce.number().int().min(1).max(104857600, { message: 'Kích thước sách tối đa là 100 MB.' }),
  rightsConfirmed: z.boolean().refine((val) => val === true, {
    message: 'Bạn phải xác nhận có quyền sử dụng tệp này cho mục đích học tập cá nhân.',
  }),
  rightsTermsVersion: z.string().default('v1.0'),
  publisher: z.string().trim().max(150).optional().nullable(),
  editionYear: z.coerce.number().int().min(1900).max(2100).optional().nullable(),
  language: z.string().default('vi'),
});

export const BookProgressUpdateSchema = z.object({
  page: z.coerce.number().int().min(1),
  chapterId: z.string().optional().nullable(),
  percentage: z.coerce.number().min(0).max(100).default(0),
});

export const BookBookmarkCreateSchema = z.object({
  page: z.coerce.number().int().min(1),
  chapterId: z.string().optional().nullable(),
  title: z.string().trim().min(1, { message: 'Tiêu đề dấu trang không được để trống' }).max(255),
  sourceAnchor: z.string().max(100).optional().nullable(),
});

export const BookHighlightCreateSchema = z.object({
  page: z.coerce.number().int().min(1),
  chapterId: z.string().optional().nullable(),
  selectedText: z.string().trim().min(1, { message: 'Đoạn văn bản được chọn không được để trống' }),
  note: z.string().max(2000).optional().nullable(),
  color: z.enum(['yellow', 'green', 'blue', 'pink', 'purple']).default('yellow'),
});

export const BookStudyAidRequestSchema = z.object({
  action: z.enum([
    'summary',
    'outline',
    'flashcards',
    'quiz',
    'explain',
    'study_plan',
    'send_to_mistake_notebook',
  ]),
  chapterId: z.string().optional().nullable(),
  startPage: z.coerce.number().int().min(1).optional().nullable(),
  endPage: z.coerce.number().int().min(1).optional().nullable(),
  conceptToExplain: z.string().optional().nullable(),
  options: z.record(z.string(), z.any()).optional(),
  idempotencyKey: z.string().optional().nullable(),
});

export const BusyEventInputSchema = z
  .object({
    title: z.string().trim().min(1, { message: 'Tiêu đề sự kiện/lịch bận không được để trống' }).max(150),
    type: z.enum(['extra_class', 'club', 'personal', 'meal', 'sleep', 'commute']).default('personal'),
    startsAt: z.string().datetime({ message: 'Thời gian bắt đầu phải là chuẩn ISO 8601 hợp lệ' }),
    endsAt: z.string().datetime({ message: 'Thời gian kết thúc phải là chuẩn ISO 8601 hợp lệ' }),
    recurrenceRule: z.string().max(100).optional().nullable(),
    timezone: z.string().default('Asia/Ho_Chi_Minh'),
    isFixed: z.boolean().default(true),
    location: z.string().trim().max(150).optional().nullable().or(z.literal('')),
    commuteBeforeMinutes: z.coerce.number().int().min(0).max(180).default(0),
    commuteAfterMinutes: z.coerce.number().int().min(0).max(180).default(0),
    subjectId: z.string().optional().nullable(),
    source: z.string().default('user'),
  })
  .refine((data) => new Date(data.startsAt).getTime() < new Date(data.endsAt).getTime(), {
    message: 'Thời gian kết thúc phải sau thời gian bắt đầu',
    path: ['endsAt'],
  });

export const AvailabilityRuleInputSchema = z
  .object({
    dayOfWeek: z.coerce.number().int().min(1).max(7),
    startLocalTime: z.string().regex(TimeStringRegex, { message: 'Giờ bắt đầu phải có định dạng HH:mm' }),
    endLocalTime: z.string().regex(TimeStringRegex, { message: 'Giờ kết thúc phải có định dạng HH:mm' }),
    type: z.enum(['available', 'preferred', 'blocked']).default('available'),
    isEnabled: z.boolean().default(true),
    effectiveFrom: z.string().optional().nullable(),
    effectiveTo: z.string().optional().nullable(),
  })
  .refine((data) => data.startLocalTime < data.endLocalTime, {
    message: 'Giờ kết thúc phải sau giờ bắt đầu',
    path: ['endLocalTime'],
  });

export const ReplanPreviewRequestSchema = z.object({
  startDate: z.string().datetime().optional(),
  daysCount: z.coerce.number().int().min(1).max(30).default(7),
  reason: z.string().optional(),
});

export const ProposalConfirmRequestSchema = z.object({
  idempotencyKey: z.string().max(64).optional(),
});

export const NotificationPreferencesUpdateSchema = z.object({
  upcomingClass: z.boolean().optional(),
  upcomingExam: z.boolean().optional(),
  incompleteTask: z.boolean().optional(),
  soundEnabled: z.boolean().optional(),
  leadMinutes: z.coerce.number().int().min(0).max(180).optional(),
  classLeadMinutes: z.coerce.number().int().min(0).max(180).optional(),
  taskLeadMinutes: z.coerce.number().int().min(0).max(180).optional(),
  examLeadDays: z.coerce.number().int().min(1).max(30).optional(),
  quietHoursStart: z.string().regex(TimeStringRegex, { message: 'Giờ bắt đầu phải có định dạng HH:mm' }).optional(),
  quietHoursEnd: z.string().regex(TimeStringRegex, { message: 'Giờ kết thúc phải có định dạng HH:mm' }).optional(),
  timezone: z.string().max(50).optional(),
  inAppEnabled: z.boolean().optional(),
  webPushEnabled: z.boolean().optional(),
  pushSubscription: z.any().optional(),
});

export const NotificationFilterQuerySchema = z.object({
  status: z.enum(['all', 'unread', 'read', 'archived']).optional().default('all'),
  type: z
    .enum([
      'all',
      'task',
      'class',
      'exam',
      'upcoming_class',
      'upcoming_exam',
      'incomplete_task',
      'task_due',
      'task_overdue',
      'focus_upcoming',
      'system',
    ])
    .optional()
    .default('all'),
  cursor: z.string().optional(),
  limit: z.coerce.number().int().min(1).max(100).optional().default(20),
});

export const MaterialUploadIntentSchema = z.object({
  title: z.string().min(1, { message: 'Tiêu đề không được để trống' }).max(200),
  subjectId: z.string().min(1, { message: 'Môn học không được để trống' }),
  fileName: z.string().min(1, { message: 'Tên file không được để trống' }),
  mimeType: z.enum([
    'application/pdf',
    'image/png',
    'image/jpeg',
    'image/jpg',
    'image/webp',
    'text/plain',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/octet-stream',
  ], { message: 'Định dạng file không được hỗ trợ. Chỉ chấp nhận PDF, PNG, JPG/JPEG, WebP, TXT, DOC/DOCX' }),
  sizeBytes: z.number().int().min(1).max(25 * 1024 * 1024, { message: 'Dung lượng file tối đa là 25MB' }),
});

export const MaterialFinalizeSchema = z.object({
  sizeBytes: z.number().int().min(1).optional(),
  sha256: z.string().length(64).optional(),
});

export const RealtimeFinalizeSchema = z.object({
  reason: z.string().trim().min(1).max(300).optional(),
}).strict();

export const MaterialNoteCreateSchema = z.object({
  title: z.string().min(1, { message: 'Tiêu đề không được để trống' }).max(200),
  subjectId: z.string().min(1, { message: 'Môn học không được để trống' }),
  contentText: z.string().min(1, { message: 'Nội dung ghi chú không được để trống' }).max(50000),
});

export const MaterialQuizGenerateSchema = z.object({
  questionCount: z.coerce.number().int().min(3).max(20).default(5),
  difficulty: z.enum(['easy', 'medium', 'hard']).default('medium'),
  title: z.string().max(200).optional(),
});

export const StructuredSummarySchema = z.object({
  overview: z.string().min(1),
  keyPoints: z.array(z.string()).min(1),
  concepts: z.array(z.object({
    name: z.string(),
    definition: z.string(),
  })).default([]),
  formulas: z.array(z.string()).optional().default([]),
  sourceReferences: z.array(z.object({
    pageOrSection: z.string(),
    note: z.string(),
  })).optional().default([]),
  warning: z.string().optional(),
});

export const ReportOverviewQuerySchema = z.object({
  period: z.enum(['week', 'month', 'custom']).optional().default('week'),
  from: z.string().optional(),
  to: z.string().optional(),
  timezone: z.string().optional(),
});

export const ExamCreateSchema = z.object({
  title: z.string().min(1, { message: 'Tiêu đề kỳ kiểm tra không được để trống' }).max(200),
  subjectId: z.string().min(1, { message: 'Vui lòng chọn môn học hợp lệ' }),
  examAt: z.string().min(1, { message: 'Ngày thi không được để trống' }),
  importance: z.enum(['low', 'medium', 'high', 'critical']).default('high'),
  scopeText: z.string().max(1000).optional().default(''),
  topics: z.array(z.object({
    id: z.string().optional(),
    name: z.string().min(1),
    weight: z.number().min(0.1).max(10).default(1),
    notes: z.string().optional(),
  })).optional().default([]),
});

export const ExamUpdateSchema = ExamCreateSchema.partial().extend({
  status: z.enum(['upcoming', 'completed', 'cancelled']).optional(),
});

export const ExamQuizGenerateSchema = z.object({
  milestone: z.enum(['D-14', 'D-7', 'D-3', 'D-1']).default('D-7'),
  questionCount: z.coerce.number().int().min(3).max(20).default(5),
  difficulty: z.enum(['easy', 'medium', 'hard']).default('medium'),
  title: z.string().max(200).optional(),
});

export const SubjectQuizGenerateSchema = z.object({
  subjectId: z.string().max(64).optional(),
  subjectName: z.string().max(100).optional(),
  topics: z.array(z.string().max(100)).max(10).optional(),
  scope: z.string().max(255).optional(),
  difficulty: z.enum(['easy', 'medium', 'hard']).default('medium'),
  questionCount: z.coerce.number().int().min(3).max(30).default(5),
  format: z.enum(['multiple_choice', 'essay', 'combined']).optional(),
  title: z.string().max(200).optional(),
});

export const QuizRetakeWrongSchema = z.object({
  originalQuizId: z.string().min(1, { message: 'Mã đề thi gốc không được để trống' }).max(64),
  wrongQuestionIds: z.array(z.string().min(1).max(64)).min(1, { message: 'Danh sách câu hỏi sai không được để trống' }).max(50),
});

export const QuizAttemptSubmitSchema = z.object({
  attemptId: z.string().optional(),
  answers: z.array(z.object({
    questionId: z.string().min(1),
    answer: z.string(),
  })).default([]),
});

export const JamiChatRequestSchema = z.object({
  message: z.string().min(1, { message: 'Nội dung tin nhắn không được để trống' }).max(2000),
  conversationId: z.string().optional(),
  clientMessageId: z.string().optional(),
  includeAudio: z.boolean().optional().default(false),
  materialId: z.string().max(64).optional(),
});

export const JamiConversationCreateSchema = z.object({
  title: z.string().min(1).max(150).optional().default('Hội thoại với Jami'),
});

export const JamiConversationUpdateSchema = z.object({
  title: z.string().min(1, { message: 'Tiêu đề không được để trống' }).max(150),
});

export const JamiMessageConfirmSchema = z.object({
  decision: z.enum(['confirm', 'reject']).default('confirm'),
});

export const FocusSessionStartSchema = z.object({
  taskId: z.string().optional().nullable().transform((v) => (v === '' || v === 'none' || v === null ? undefined : v)),
  mode: z.string().optional().default('25_5'),
  minutes: z.coerce.number().int().min(1, { message: 'Thời gian tối thiểu là 1 phút' }).max(300, { message: 'Thời gian tối đa là 300 phút' }).optional(),
  breakMinutes: z.coerce.number().int().min(1).max(60).optional(),
  idempotencyKey: z.string().max(64).optional().nullable().transform((v) => v || undefined),
});

export const FocusSessionActionSchema = z.object({
  notes: z.string().max(1000).optional(),
  outcome: z.string().max(50).optional(),
  idempotencyKey: z.string().max(64).optional(),
});

export const TaskCreateSchema = z.object({
  title: z.string().min(1, { message: 'Tiêu đề nhiệm vụ không được để trống' }).max(200),
  subjectId: z.string().min(1, { message: 'Vui lòng chọn môn học' }),
  objective: z.string().max(1000).optional(),
  priority: z.enum(['low', 'medium', 'high']).default('medium'),
  difficulty: z.enum(['easy', 'medium', 'hard']).default('medium'),
  estimatedMinutes: z.coerce.number().int().min(5, { message: 'Thời gian ước tính tối thiểu là 5 phút' }).max(300, { message: 'Thời gian ước tính tối đa là 300 phút' }).default(45),
  dueAt: z.string().optional(),
  scheduledStartAt: z.string().optional(),
  examId: z.string().optional(),
  splittable: z.boolean().optional().default(false),
  locked: z.boolean().optional().default(false),
});

export const TaskUpdateSchema = TaskCreateSchema.partial().extend({
  status: z.enum(['pending', 'in_progress', 'completed', 'cancelled']).optional(),
  completionPercent: z.coerce.number().min(0).max(100).optional(),
});

export const ExecutionGuideGenerateSchema = z.object({
  additionalNotes: z.string().max(1000).optional(),
});

export const ChecklistItemUpdateSchema = z.object({
  checked: z.boolean(),
});

export const StepActionSchema = z.object({
  status: z.enum(['pending', 'in_progress', 'completed']),
  actualMinutes: z.coerce.number().int().min(0).max(300).optional(),
});

export const TaskEvidenceSubmitSchema = z.object({
  type: z.enum(['image', 'text', 'quiz_result', 'file', 'link']).default('text'),
  rating: z.coerce.number().int().min(1).max(5).default(5),
  evidenceNote: z.string().min(1, { message: 'Ghi chú minh chứng không được để trống' }).max(2000),
  fileUrl: z.string().optional(),
  r2ObjectKey: z.string().optional(),
});

export const ExecutionStepSchema = z.object({
  stepOrder: z.number().int().min(1),
  title: z.string().min(1),
  plannedMinutes: z.number().int().min(1),
  instruction: z.string().min(1),
  expectedOutput: z.string().min(1),
  tips: z.array(z.string()).default([]),
});

export const ExecutionGuideOutputSchema = z.object({
  objective: z.string().min(1),
  whyItMatters: z.string().min(1),
  prerequisites: z.array(z.string()).default([]),
  materials: z.array(z.string()).default([]),
  preparationChecklist: z.array(z.object({
    id: z.string().optional(),
    text: z.string().min(1),
    checked: z.boolean().default(false),
  })).default([]),
  steps: z.array(ExecutionStepSchema).min(1),
  successCriteria: z.array(z.string()).default([]),
  excellentCriteria: z.array(z.string()).default([]),
  evidenceRequired: z.array(z.string()).default([]),
  commonMistakes: z.array(z.string()).default([]),
  fallbackAction: z.string().default('Nếu gặp khó khăn quá 5 phút, hãy tạm thời bỏ qua hoặc hỏi trợ lý Jami AI.'),
  completionQuestions: z.array(z.string()).default([]),
  nextAction: z.string().default('Chuyển sang làm bài tập vận dụng nâng cao.'),
});

export const TomorrowPlanGenerateRequestSchema = z.object({
  energyLevel: z.enum(['high', 'normal', 'low', 'due_only', 'skip']).default('normal'),
  customAvailableMinutes: z.coerce.number().int().min(10).max(300).optional(),
});

export const TomorrowPlanEnergyUpdateRequestSchema = z.object({
  energyLevel: z.enum(['high', 'normal', 'low', 'due_only', 'skip']),
});

export const TomorrowPlanItemUpdateRequestSchema = z.object({
  title: z.string().trim().min(1).max(255).optional(),
  description: z.string().optional().nullable(),
  reason: z.string().optional().nullable(),
  plannedMinutes: z.coerce.number().int().min(5).max(180).optional(),
  startAt: z.string().regex(TimeStringRegex).optional(),
  endAt: z.string().regex(TimeStringRegex).optional(),
  status: z.enum(['pending', 'in_progress', 'completed', 'skipped']).optional(),
});

export const TomorrowPlanAiSuggestionItemSchema = z.object({
  subjectId: z.string().optional().nullable(),
  title: z.string().min(1),
  description: z.string().optional().nullable(),
  reason: z.string().optional().nullable(),
  plannedMinutes: z.coerce.number().int().min(5).max(60).default(15),
  priority: z.enum(['high', 'medium', 'low']).default('medium'),
  sourceType: z.enum([
    'due_task',
    'exam_review',
    'class_checkin_reflection',
    'class_checkin_homework',
    'tomorrow_subject_preview',
    'pack_bag',
    'general_review',
  ]).default('general_review'),
  sourceId: z.string().optional().nullable(),
});

export const TomorrowPlanAiSuggestionsResponseSchema = z.object({
  suggestions: z.array(TomorrowPlanAiSuggestionItemSchema),
});

// ==========================================
// Exam Study Plan Schemas
// ==========================================

export const ExamStudyPlanGenerateSchema = z.object({
  startDate: z.string().optional(),
  dailyMinutes: z.coerce.number().int().min(15).max(180).default(45),
  blackoutDates: z.array(z.string()).default([]),
});

export const ExamStudyPlanItemUpdateSchema = z.object({
  title: z.string().trim().min(1).max(255).optional(),
  description: z.string().optional().nullable(),
  plannedDate: z.string().optional(),
  startAt: z.string().regex(TimeStringRegex).optional(),
  endAt: z.string().regex(TimeStringRegex).optional(),
  plannedMinutes: z.coerce.number().int().min(10).max(180).optional(),
  status: z.enum(['pending', 'in_progress', 'completed', 'missed', 'skipped']).optional(),
});

export const ExamStudyPlanReplanConfirmSchema = z.object({
  action: z.enum(['accept', 'custom_slot', 'skip_session', 'keep_as_is']),
  customSlot: z
    .object({
      plannedDate: z.string(),
      startAt: z.string().regex(TimeStringRegex),
      endAt: z.string().regex(TimeStringRegex),
    })
    .optional(),
});

// ==========================================
// Mistake Notebook Schemas
// ==========================================

export const MistakeReasonEnum = z.enum([
  'knowledge_gap',
  'misread_question',
  'calculation_error',
  'wrong_choice',
  'time_pressure',
  'not_learned_yet',
  'other',
]);

export const MistakeStatusEnum = z.enum(['new', 'reviewing', 'needs_retry', 'mastered']);
export const MistakeDifficultyEnum = z.enum(['easy', 'medium', 'hard']);
export const MistakeSourceTypeEnum = z.enum(['quiz', 'exam_mock', 'manual', 'class_exercise']);

export const MistakeCreateSchema = z.object({
  subjectId: z.string().optional().nullable(),
  topic: z.string().trim().min(1, { message: 'Chủ đề / Chương không được để trống' }).max(150),
  questionText: z.string().trim().min(1, { message: 'Nội dung câu hỏi không được để trống' }),
  questionDataJson: z.string().optional().nullable(),
  selectedAnswer: z.string().optional().nullable(),
  correctAnswer: z.string().trim().min(1, { message: 'Đáp án đúng không được để trống' }),
  mistakeReason: MistakeReasonEnum.default('other'),
  correctExplanation: z.string().optional().nullable(),
  difficulty: MistakeDifficultyEnum.default('medium'),
  sourceType: MistakeSourceTypeEnum.default('manual'),
  sourceId: z.string().optional().nullable(),
});

export const MistakeUpdateSchema = z.object({
  subjectId: z.string().optional().nullable(),
  topic: z.string().trim().min(1).max(150).optional(),
  questionText: z.string().trim().min(1).optional(),
  selectedAnswer: z.string().optional().nullable(),
  correctAnswer: z.string().trim().min(1).optional(),
  mistakeReason: MistakeReasonEnum.optional(),
  correctExplanation: z.string().optional().nullable(),
  difficulty: MistakeDifficultyEnum.optional(),
  status: MistakeStatusEnum.optional(),
});

export const MistakeReviewSubmitSchema = z.object({
  answer: z.string().trim().min(1, { message: 'Vui lòng nhập hoặc chọn câu trả lời' }),
});

export const MistakeSimilarQuestionSchema = z.object({
  questionText: z.string().min(1),
  options: z.array(z.string()).optional(),
  correctAnswer: z.string().min(1),
  explanation: z.string().min(1),
  difficulty: MistakeDifficultyEnum.default('medium'),
});

export const BusyEventExceptionCreateSchema = z.object({
  occurrenceDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, { message: 'Ngày ngoại lệ không đúng định dạng YYYY-MM-DD' }),
  reason: z.string().trim().max(255).optional(),
  exceptionType: z.enum(['cancelled', 'skip']).default('cancelled'),
});

export const AdminTopUpWalletSchema = z.object({
  amountVnd: z.number().int().min(1000, { message: 'Số tiền nạp tối thiểu 1.000đ' }).max(100000000, { message: 'Số tiền nạp tối đa 100.000.000đ' }),
  reason: z.string().trim().min(3, { message: 'Lý do tối thiểu 3 ký tự' }).max(500, { message: 'Lý do tối đa 500 ký tự' }),
  idempotencyKey: z.string().trim().min(8, { message: 'idempotencyKey tối thiểu 8 ký tự' }).max(150),
}).strict();

export const AdminDeductWalletSchema = z.object({
  amountVnd: z.number().int().min(1000, { message: 'Số tiền trừ tối thiểu 1.000đ' }).max(100000000, { message: 'Số tiền trừ tối đa 100.000.000đ' }),
  reason: z.string().trim().min(3, { message: 'Lý do tối thiểu 3 ký tự' }).max(500, { message: 'Lý do tối đa 500 ký tự' }),
  idempotencyKey: z.string().trim().min(8, { message: 'idempotencyKey tối thiểu 8 ký tự' }).max(150),
}).strict();

export const AdminSetUnlimitedWalletSchema = z.object({
  unlimitedForever: z.boolean(),
  unlimitedUntil: z.string().datetime({ message: 'Thời hạn không đúng chuẩn ISO date' }).optional().nullable(),
  reason: z.string().trim().min(3, { message: 'Lý do tối thiểu 3 ký tự' }).max(500, { message: 'Lý do tối đa 500 ký tự' }),
  idempotencyKey: z.string().trim().min(8, { message: 'idempotencyKey tối thiểu 8 ký tự' }).max(150),
}).strict();

export const AdminSetWalletStatusSchema = z.object({
  aiEnabled: z.boolean(),
  reason: z.string().trim().min(3, { message: 'Lý do tối thiểu 3 ký tự' }).max(500, { message: 'Lý do tối đa 500 ký tự' }),
  idempotencyKey: z.string().trim().min(8, { message: 'idempotencyKey tối thiểu 8 ký tự' }).max(150),
}).strict();

export const AdminCreateRegistrationCodeSchema = z.object({
  rewardType: z.enum(['credit', 'unlimited']),
  creditVnd: z.number().int().min(1000).max(100000000).optional().nullable(),
  unlimitedForever: z.boolean().default(false),
  unlimitedUntil: z.string().datetime().optional().nullable(),
  maxRedemptions: z.number().int().min(1).max(100000).default(1),
  startsAt: z.string().datetime().optional().nullable(),
  expiresAt: z.string().datetime().optional().nullable(),
  note: z.string().trim().max(500).optional().nullable(),
}).strict().superRefine((data, ctx) => {
  if (data.rewardType === 'credit') {
    if (!data.creditVnd || data.creditVnd <= 0) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['creditVnd'],
        message: 'Mã loại nạp tiền bắt buộc phải có số tiền creditVnd lớn hơn 0',
      });
    }
    if (data.unlimitedForever || data.unlimitedUntil) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['rewardType'],
        message: 'Mã loại credit không được chứa thiết lập vô hạn (unlimited)',
      });
    }
  } else if (data.rewardType === 'unlimited') {
    if (data.creditVnd && data.creditVnd > 0) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['creditVnd'],
        message: 'Mã loại unlimited không được chứa số tiền creditVnd',
      });
    }
    if (!data.unlimitedForever && !data.unlimitedUntil) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['unlimitedForever'],
        message: 'Mã loại unlimited phải chọn vĩnh viễn (unlimitedForever) hoặc có ngày hết hạn (unlimitedUntil)',
      });
    }
    if (data.unlimitedUntil && new Date(data.unlimitedUntil).getTime() <= Date.now()) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['unlimitedUntil'],
        message: 'Thời hạn vô hạn (unlimitedUntil) phải là ngày trong tương lai',
      });
    }
  }

  if (data.startsAt && data.expiresAt) {
    if (new Date(data.startsAt).getTime() >= new Date(data.expiresAt).getTime()) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['expiresAt'],
        message: 'Ngày kết thúc (expiresAt) phải sau ngày bắt đầu (startsAt)',
      });
    }
  }
});

export const AdminRevokeRegistrationCodeSchema = z.object({
  reason: z.string().trim().min(3, { message: 'Lý do thu hồi tối thiểu 3 ký tự' }).max(500),
}).strict();



