-- Canonical Jami turns must retain replayable results; tasks are allowed without a subject.
ALTER TABLE study_tasks MODIFY COLUMN subject_id VARCHAR(64) NULL;

-- Older installations may not have all turn failure metadata after partial migrations.
ALTER TABLE jami_turns ADD COLUMN IF NOT EXISTS error_code VARCHAR(64) NULL;
